#import getObj
import time
import numpy as np

def moveRobot(pos,rob):
    if pos == 'active':
        print('Active')
        print('Active')
        print('Active')
        targetPose = [-0.29790689669655784, 0.34562517431052564, 0.08768988800174216, 2.7824050574403794, 1.22958115977986, 0.07235681221214063]
        rob.movep(targetPose, acc=1, vel=0.07, wait=False)

    elif pos == 'draw':
        print('Draw')
        print('Draw')
        print('Draw')
        pose = rob.getl()
        l = 0.2
        v = 0.07
        a = 0.1
        r = 0.05
        pose[2] += l
        rob.movep(pose, acc=a, vel=v, wait=False)
        while True:
            p = rob.getl(wait=True)
            if p[2] > pose[2] - 0.05:
                break
        time.sleep(1)
        pose[1] += l 
        rob.movep(pose, acc=a, vel=v, wait=False)
        while True:
            p = rob.getl(wait=True)
            if p[1] > pose[1] - 0.05:
                break
        time.sleep(1)
        pose[2] -= l
        rob.movep(pose, acc=a, vel=v, wait=False)
        while True:
            p = rob.getl(wait=True)
            if p[2] < pose[2] + 0.05:
                break
        time.sleep(1)
        pose[1] -= l
        rob.movep(pose, acc=a, vel=v, wait=False)