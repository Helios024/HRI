import os
from ultralytics import YOLO
from ultralytics.yolo.utils.plotting import Annotator
import cv2
import time
import numpy as np
home = os.getcwd()
model = YOLO(r'C:\Users\zohai\Projects\HRI\python-urx\src\best.pt')
def annotate_frame(frame,detect):
    annotator = Annotator(frame)
    for res in detect:
        for box in res.boxes:
            b= box.xyxy[0] #extract bounding box
            if b[1] > 100:
                c = box.cls
                annotator.box_label(b,str(res.names[int(c)])+str(round(float(box.conf),2))) #annotate box

def get_dimensions(frame,detect):
    dimensions = []
    for res in detect:
        for box in res.boxes:
            b = box.xyxy[0]
            x_min = b[0]  # Minimum x-coordinate
            y_min = b[1]  # Minimum y-coordinate
            x_max = b[2]  # Maximum x-coordinate
            y_max = b[3]  # Maximum y-coordinate
            width = x_max - x_min
            height = y_max - y_min
    dimensions.append((height,width))
    return dimensions[0]

def getOrientation(lenght):
    from sympy import symbols,cos,sin,Eq,solve
    theta = symbols('Q')
    eqn = Eq(177.9*cos(theta) + 84.4*sin(theta),lenght)
    sol = solve(eqn,theta)
    return (sol[1])

def get_distances(frame,detect):
    for res in detect:
        for box in res.boxes:
            b = box.xyxy[0]
            x_min = b[0]  # Minimum x-coordinate
            y_min = b[1]  # Minimum y-coordinate
            x_max = b[2]  # Maximum x-coordinate
            y_max = b[3]  # Maximum y-coordinate
            width = x_max - x_min
            height = y_max - y_min
            distances = [x_min + width/2, y_min + height/2]
    return distances

def getPosition(lenght,height):
    return [lenght/2,height/2]
z=35.5

def calculatePixelpercm(z):
    pixel_13cm = 0.161*z**2 - 19.64*z + 756.9087
    return pixel_13cm/13 

def centimeterToPixel(z,x,y):
    pixel_1cm =  calculatePixelpercm(z)
    return [x*pixel_1cm, y*pixel_1cm]

def pixelToCentimeter(z,x,y):
    pixel_1cm = calculatePixelpercm(z)
    return [x/pixel_1cm, y/pixel_1cm]

def getBoxOrientationNPos(camPort):
    time.sleep(5)
    vidcap = cv2.VideoCapture(camPort)
    vidcap.set(3,848)
    vidcap.set(4,480)
    for i in range (30): #get few frames in case it might detect in the first few frames
        ret,frame = vidcap.read()
        detect = model.predict(source=frame,conf=0.25,save=False)
        annotate_frame(frame,detect)
        cv2.imshow('Box Detection',frame)
        if cv2.waitKey(10) & 0xFF == ord('q'):
            break
    height,lenght = get_distances(frame,detect)
    vidcap.release()
    cv2.destroyAllWindows()
    return get_distances(frame,detect)

def ObjPosOrigin(camPort):
    xpix,ypix = getBoxOrientationNPos(camPort)
    xorigin,yorigin = 424,240
    return [pixelToCentimeter(xorigin-xpix), pixelToCentimeter(yorigin-ypix)]
