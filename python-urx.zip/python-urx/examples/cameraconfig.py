import time 
import urx
import logging
import math as mt
import numpy as np

def Link(th, d, a, alp):
    Tth = np.array([[math.cos(th), -math.sin(th), 0, 0],
                   [math.sin(th), math.cos(th), 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
    Td = np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, d], [0, 0, 0, 1]])
    Ta = np.array([[1, 0, 0, a], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
    Talp = np.array([[1, 0, 0, 0], [0, math.cos(alp), -math.sin(alp), 0],
                    [0, math.sin(alp), math.cos(alp), 0], [0, 0, 0, 1]])
    T = np.dot(Tth, np.dot(Td, np.dot(Ta, Talp)))
    return (T)


def LinkSerialRobot(A):
    s = len(A)
    Robot = A[s-1]
    for i in range(1, s):
        Robot = np.dot(A[s-(i+1)], Robot)
    return (Robot)


def frame_transform(x, y, z, state):
    # print("State inside FT= ", state)
    #[t1, t2, t3, t4, t5, t6] = [0.5,0.5,0.5,0.5,0.5,0.5]
    [t1, t2, t3, t4, t5, t6] = np.deg2rad(state)
    # print("State inside frame transform", state)
    # L1 = Link(t1, 89.159, 0, math.pi/2)  ## all angles in radians
    L1 = Link(t1, 100.0, 0, math.pi/2)
    L2 = Link(t2, 135.85, -425.0, 0)
    L3 = Link(t3, -119.7, -392.25, 0)
    L4 = Link(t4, 93.0, 0, math.pi/2)
    L5 = Link(t5, 94.65, 0, -math.pi/2)
    L6 = Link(t6, 82.3, 0, math.pi)
    pos = np.array([[1, 0, 0, 0], [0, 1, 0, -10],
                   [0, 0, 1, -18], [0, 0, 0, 1]])
    FK = LinkSerialRobot([L1, L2, L3, L4, L5, L6])
    FK = np.dot(FK, pos)

    x = round(((FK[0][3])/10), 1)
    y = round(((FK[1][3])/10), 1)
    z = round(((FK[2][3])/10), 1)
    # print("Transformed_pos = ", transformed_pos)

    return x, y, z

def forward_kinematics(k,j,theta_list): #kRj
    ti_j = np.identity(4)
    d_list = [0.089159,0,0,0.10915,0.09465,0.0823]
    a_list = [0,-0.425,-0.39225,0,0,0]
    alpha_list = [mt.pi/2,0,0,mt.pi/2,-1*mt.pi/2,0]
    for i in range (k,j):
        t_d = [[mt.cos(theta_list[i]),-1*mt.sin(theta_list[i])*mt.cos(alpha_list[i]),mt.sin(theta_list[i])*mt.sin(alpha_list[i]),a_list[i]*mt.cos(theta_list[i])],
               [mt.sin(theta_list[i]),mt.cos(theta_list[i])*mt.cos(alpha_list[i]),-1*mt.cos(theta_list[i])*mt.sin(alpha_list[i]),a_list[i]*mt.sin(theta_list[i])],
               [0,mt.sin(alpha_list[i]),mt.cos(alpha_list[i]),d_list[i]],
               [0,0,0,1]]
        ti_j = ti_j @ t_d
    return ti_j

if __name__ == "__main__":
    rob = urx.Robot("192.168.1.6")
    try:
        joint_positions = rob.get_joint()
        print(joint_positions)
        base_endeffector = forward_kinematics(0,6,joint_positions)
        endeffector_camera = [[1,0,0,0],[0,1,0,-10],[0,0,1,-18],[0,0,0,1]]
        base_camera = base_endeffector * endeffector_camera
        print(base_camera)
    finally:
        rob.close()

