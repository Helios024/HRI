import time 
import urx
import logging
import collections
collections.Iterable = collections.abc.Iterable

if __name__ == "__main__":
    rob = urx.Robot("192.168.0.112")
    try:
        pose = rob.getl()
        l = 0.2
        v = 0.07
        a = 0.1
        r = 0.05
        pose[2] += l
        rob.movep(pose, acc=a, vel=v, wait=False)
        while True:
            p = rob.getl(wait=True)
            if p[2] > pose[2] - 0.05:
                break
        time.sleep(1)
        pose[1] += l 
        rob.movep(pose, acc=a, vel=v, wait=False)
        while True:
            p = rob.getl(wait=True)
            if p[1] > pose[1] - 0.05:
                break
        time.sleep(1)
        pose[2] -= l
        rob.movep(pose, acc=a, vel=v, wait=False)
        while True:
            p = rob.getl(wait=True)
            if p[2] < pose[2] + 0.05:
                break
        time.sleep(1)
        pose[1] -= l
        rob.movep(pose, acc=a, vel=v, wait=True)

    finally:
        rob.close()

