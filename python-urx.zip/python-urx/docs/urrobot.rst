
URRobot Object
=========================================

.. autoclass:: urx.robot.URRobot
   :members:
   :undoc-members:

   .. autoattribute: 

