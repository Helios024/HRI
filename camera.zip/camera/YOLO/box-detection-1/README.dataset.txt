# box-detection > 2023-07-10 3:20pm
https://universe.roboflow.com/brunel-university-london/box-detection-dbztg

Provided by a Roboflow user
License: CC BY 4.0

